from typing import Tuple
import ghostscript
import os
from PyPDF2 import PdfReader

def render_pdf(input_pdf: str, output_pdf: str, quality: str = "high") -> Tuple[bool, str | None]:
    """Render PDF using Ghostscript.

    Returns (True, None) on success, or (False, error_message) on failure.
    This function does not show any UI; callers should handle messaging.
    """
    try:
        # Basic existence check
        if not os.path.exists(input_pdf):
            return False, "Input file does not exist"

        # Check for password-protected PDFs
        try:
            reader = PdfReader(input_pdf)
            if getattr(reader, "is_encrypted", False):
                return False, "PDF is password-protected and cannot be processed."
        except Exception:
            # If PyPDF2 fails to read due to restriction flags, continue and let Ghostscript try
            pass

        quality_settings = {
            "high": ["-dPDFSETTINGS=/prepress", "-r300"],
            "medium": ["-dPDFSETTINGS=/ebook", "-r150"],
            "low": ["-dPDFSETTINGS=/screen", "-r72"],
        }

        quality_args = quality_settings.get(quality, quality_settings["high"])

        args = [
            "gs",
            "-q",
            "-dNOPAUSE",
            "-dBATCH",
            "-sDEVICE=pdfwrite",
            "-dRemoveHiddenStrings",
            "-dRemoveDuplicateImages",
        ] + quality_args + [f"-sOutputFile={output_pdf}", input_pdf]

        gs_args = [a.encode("utf-8") for a in args]

        try:
            # ghostscript.Ghostscript can raise on error; call it and return accordingly
            ghostscript.Ghostscript(*gs_args)
            return True, None
        except Exception as e:
            return False, f"Ghostscript error: {e}"
    except Exception as exc:  # unexpected
        return False, str(exc)
